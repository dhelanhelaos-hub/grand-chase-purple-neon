# Grand Chase Purple Neon — Poweramp V3 skin starter

This is a **source overlay and design starter**, not an APK. It is intended to be applied to the official Poweramp V3 skin sample project.

## Design direction
- Deep violet / near-black surfaces
- Electric purple highlights and glow accents
- White text for contrast
- Grand Chase-inspired fantasy artwork (see `design/`)
- Skin name: Grand Chase Purple Neon

## Important compatibility note
Poweramp V3 skins are Android APKs that override Poweramp's resource styles. The official SDK sample is required. This folder deliberately does not invent or redistribute the SDK/reference resources.

Official source:
https://github.com/maxmpz/powerampapi/tree/master/poweramp_skin_sdk

Official skin sample guide:
https://github.com/maxmpz/powerampapi/blob/master/poweramp_skin_sample/readme.md

## What's included
- `skin-overlay/`: initial XML overlay files to merge into the official sample, after checking the sample's exact resource names.
- `design/`: visual concept reference.
- `.github/workflows/android-build.yml`: a starter GitHub Actions workflow template. It expects the official sample project to be present in this repository and its Gradle wrapper at the repository root.

## Next integration step
1. Copy the official `poweramp_skin_sample` project into this repository (preserve its Gradle files, SDK resources and license).
2. Compare its `res/xml/skins.xml` and style naming with `skin-overlay/`.
3. Merge the theme metadata and values into the sample. Do not replace the SDK's original styles wholesale.
4. Run the GitHub Actions workflow and fix any build errors shown in the Actions log.

## Poweramp verification
A locally built third-party skin may show as `[unverified]` in newer Poweramp builds. The official sample README explains the allowlisting process. Do not assume a locally built APK is verified.
