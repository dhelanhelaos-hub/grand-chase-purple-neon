# Theme tokens — Grand Chase Purple Neon

| Token | Hex | Use |
|---|---:|---|
| Background | `#080414` | Main near-black violet |
| Surface | `#120824` | Cards and panels |
| Surface elevated | `#1D0B38` | Selected rows |
| Primary | `#B52CFF` | Main neon purple |
| Primary bright | `#E2A6FF` | Glows and active controls |
| Secondary | `#6B2BCE` | Secondary accents |
| Text primary | `#FFFFFF` | Main text |
| Text secondary | `#D8C9EA` | Secondary text |
| Divider | `#563078` | Fine separators |

Design goals:
- Keep text contrast high; do not use glow behind small text.
- Use the concept image as visual direction, not as a literal full-screen replacement.
- Poweramp V3 controls are styled through the SDK's existing style hierarchy. Avoid replacing core layouts.
